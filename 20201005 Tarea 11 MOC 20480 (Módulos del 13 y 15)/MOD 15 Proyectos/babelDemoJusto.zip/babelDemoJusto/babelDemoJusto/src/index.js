﻿let customer = { name: "Joann Chambers" };
let message = `Hello ${customer.name}`;